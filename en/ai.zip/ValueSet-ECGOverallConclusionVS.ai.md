# ECG Overall Conclusion (placeholder) - HL7 Europe Electrocardiogram (ECG) Report v0.1.0-ci-build

## ValueSet: ECG Overall Conclusion (placeholder) 

 **References** 

* [ECG examination model](StructureDefinition-EHDSECGExamination.md)
* [ECG report model](StructureDefinition-EHDSECGReport.md)

### Logical Definition (CLD)

No formal definition provided for this value set

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ECGOverallConclusionVS",
  "url" : "http://hl7.eu/fhir/ecg/ValueSet/ECGOverallConclusionVS",
  "version" : "0.1.0-ci-build",
  "name" : "ECGOverallConclusionVS",
  "title" : "ECG Overall Conclusion (placeholder)",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-11-06T23:02:43+01:00",
  "publisher" : "HL7 Europe",
  "contact" : [{
    "name" : "HL7 Europe",
    "telecom" : [{
      "system" : "url",
      "value" : "http://hl7.eu"
    }]
  }],
  "description" : "TODO: placeholder value set, to be defined.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "150",
      "display" : "Europe"
    }]
  }],
  "copyright" : "Copyright HL7 Europe. Licensed under creative commons public domain (CC0 1.0)."
}

```
