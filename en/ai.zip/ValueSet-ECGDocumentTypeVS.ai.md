# ECG Document Type (placeholder) - HL7 Europe Electrocardiogram (ECG) Report v0.1.0-ci-build

## ValueSet: ECG Document Type (placeholder) 

 **References** 

* [ECG report model](StructureDefinition-EHDSECGReport.md)
* [ECG result document model](StructureDefinition-EHDSECGResultDocument.md)
* [Composition: ECG Report (EU)](StructureDefinition-composition-eu-ecg.md)
* [DiagnosticReport: ECG Report (EU)](StructureDefinition-diagnosticreport-eu-ecg.md)

### Logical Definition (CLD)

No formal definition provided for this value set

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ECGDocumentTypeVS",
  "url" : "http://hl7.eu/fhir/ecg/ValueSet/ECGDocumentTypeVS",
  "version" : "0.1.0-ci-build",
  "name" : "ECGDocumentTypeVS",
  "title" : "ECG Document Type (placeholder)",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-11-06T23:27:14+01:00",
  "publisher" : "HL7 Europe",
  "contact" : [{
    "name" : "HL7 Europe",
    "telecom" : [{
      "system" : "url",
      "value" : "http://hl7.eu"
    }]
  }],
  "description" : "TODO: placeholder value set, to be defined.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "150",
      "display" : "Europe"
    }]
  }],
  "copyright" : "Copyright HL7 Europe. Licensed under creative commons public domain (CC0 1.0)."
}

```
